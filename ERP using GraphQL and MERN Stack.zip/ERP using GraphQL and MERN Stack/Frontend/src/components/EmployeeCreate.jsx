import React from 'react'
import { useState } from 'react'
import '../styles/EmployeeCreate.css'
import EmployeePost from '../apicalls/EmployeePost'
import {gql,useMutation} from '@apollo/client'
import ValidationMessage from './ValidationMessage'
import { useNavigate } from 'react-router-dom'
import { Form } from 'react-bootstrap'

function EmployeeCreate() {
    const[inputs,setInputs] = useState({CurrentStatus:1,title:"Employee",
    department:"IT",
    employeeType:"part-time"})
    const[verrors,setVerrors] = useState({firstName:"",
    lastName:"",
    age:"",
    startDate:"",
    title:"",
    department:"",
    employeeType:""})

    const ADD_EMPLOYEE = EmployeePost.insert();

    const [addEmployee, { data, loading, error }] = useMutation(ADD_EMPLOYEE);

    if (loading) return 'Submitting...';
    if (error) return `Submission error! ${error.message}`;

 
    const changeHandler = (event)=>{

        const name = event.target.name
        const value = event.target.value

        setInputs((values)=>({
            ...values ,[name]:value
        }))
    }

    const submitHandler = async (e)=>{

        e.preventDefault()
        const keys = ["firstName","lastName","age","startDate"]
        console.log(inputs)
        // Empty field check
        keys.forEach((key)=>{
            if(!inputs.hasOwnProperty(key)){
                verrors[key]=`${key} cannot be empty`
            }
        })

        if(verrors.age<20 && verrors.age>70){
            verrors.age = 'Employee Age must be between 20 and 70.'
        }

        setVerrors({...verrors})
        
        if(verrors.age==""&&
         verrors.firstName=="" && 
         verrors.lastName=="" && 
         verrors.employeeType=="" && 
         verrors.title=="" && 
         verrors.department=="" &&
         verrors.startDate=="")
        {
        addEmployee(
            { variables: 
                { post:{
        FirstName : inputs.firstName,
        LastName : inputs.lastName,
        Age : parseInt(inputs.age),
        DateOfJoining : inputs.startDate,
        Title : inputs.title,
        Department : inputs.department, 
        EmployeeType : inputs.employeeType,
        CurrentStatus : parseInt(inputs.CurrentStatus)
                } 
            } 
        }).then(()=>{window.location.href="/showall";})
    }
        
    }

  return (
    <div>
        <h3> Enter details of a new employee here </h3>
        <form onSubmit={submitHandler}>
        <div className="form-group">
            <label for="firstName">First Name:</label>
            <input type="text" className="form-control" id="firstName" name='firstName' value={inputs.firstName} placeholder="First Name"  onChange={changeHandler}/>
            <ValidationMessage msg= {verrors.firstName} />
        </div>
        <div className="form-group">
            <label for="lastName">Last Name:</label>
            <input type="text" className="form-control" id="lastName"  name='lastName' value={inputs.lastName} placeholder="Last Name"   onChange={changeHandler}/>
            <ValidationMessage msg={verrors.lastName} />
        </div>
        <div className="form-group">
            <label for="age">Age:</label>
            <input type="number" className="form-control" id="age"  name='age' value={inputs.age} placeholder="20"   onChange={changeHandler} />
            <ValidationMessage msg={verrors.age} />
        </div>
        <div className="form-group">
            <label for="startDate">Date Of Joining</label>
            <input type="date" className="form-control" id="startDate"  value={inputs.startDate} name='startDate'   onChange={changeHandler}/>
            <ValidationMessage msg={verrors.startDate} />
        </div>
        <div className="form-group">
            <label for='title'> Job Title </label>
             <Form.Select bsPrefix="form-control" id='title' name='title' value={inputs.title} 
              onChange={changeHandler}>
                <option  value="Employee">Employee</option>
                <option value="Manager">Manager</option>
                <option value="Director">Director</option>
                <option value="V.P">V.P.</option>
            </Form.Select>
            <ValidationMessage msg={verrors.title} />
        </div>
        <div className="form-group">
        <label for='department'> Department </label>
             <Form.Select  bsPrefix="form-control"  id='department' name='department' value={inputs.department}   onChange={changeHandler}>
                <option  value="IT" >IT</option>
                <option value="Marketing">Marketing</option>
                <option value="Engineering">Engineering </option>
                <option value="H.R">H.R.</option>
            </Form.Select>
        <ValidationMessage msg={verrors.department}/>
        </div>
        <div className="form-group">
        <label for='employeeType'> Employee Type </label>
             <Form.Select bsPrefix="form-control" id='employeeType' name='employeeType' value={inputs.employeeType}  onChange={changeHandler}>
                <option  value="part-time" >Part Time</option>
                <option value="full-time">Full Time</option>
                <option value="contract">Contract</option>
                <option value="seasonal">Seasonal</option>
            </Form.Select>
            <ValidationMessage msg={verrors.employeeType} />
        </div>
        <div className="form-group">
            <label for="CurrentStatus">Current Status:</label>
            <input type="number" className="form-control" id="CurrentStatus"  name='CurrentStatus' 
            value={inputs.CurrentStatus}  onChange={changeHandler} />
        </div>
        <div className='form-group-btn'>
            <button type='submit' className='btn btn-primary'>Create </button>
        </div>
        </form>
    </div>
  )
}

export default EmployeeCreate