import React from 'react'
import { Navbar, Nav, NavDropdown } from "react-bootstrap";
import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>
    <Navbar bg='primary' >
      <Navbar.Brand href="/" color='white'>Home</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="mr-auto">
          <Nav.Link href="/showall">Employee List</Nav.Link>
          <Nav.Link href="/create">Add a new Employee</Nav.Link>
          <Nav.Link href="/UpcomingEvents">Upcoming Retirements</Nav.Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
      <Outlet />
    </>
  )
};

export default Layout;