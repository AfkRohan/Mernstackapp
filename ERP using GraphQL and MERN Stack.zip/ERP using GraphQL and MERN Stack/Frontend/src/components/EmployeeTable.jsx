import { useEffect, useState } from 'react'
import React from 'react'
import EmployeePost from '../apicalls/EmployeePost'
import { useQuery, gql, useMutation } from "@apollo/client";
import DeleteButton from './DeleteButton';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';

const EMPS_QUERY = EmployeePost.getEmployeesFromDb();

const searchParam = new URLSearchParams(window.location.search).get("emplsearch") ?? '';

function EmployeeTable() {
  
  const{ data, loading, error } = useQuery(EMPS_QUERY);
  const [employeeFilter,setFilter] = useState("")

  if (loading) return "Loading...";


  if (error) return <pre>{error.message}</pre>
  console.log(data?.getAllPosts);

  return (
     <><Form.Select bsPrefix="form-control" onChange={function () { 
      setFilter(event.target.value); 
      }}>
      <option value=""> All </option>
      <option value="full-time">Full Time</option>
      <option value="part-time">Part Time</option>
      <option value="contract">Contract</option>
      <option value="seasonal">Seasonal</option>
    </Form.Select><div>
      <h4>{employeeFilter}</h4>
        <h3> Employees </h3>
        <Table striped bordered hover size="sm">
          <caption>List of Employees</caption>
          <thead>
            <tr>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Age</th>
              <th scope="col">Date Of Joining</th>
              <th scope="col">Title</th>
              <th scope="col">Department</th>
              <th scope="col">Employee Type</th>
              <th scope="col">Current Status</th>
              <th scope='col'></th>
            </tr>
          </thead>
          <tbody>
            {(data.getAllPosts !== undefined && data.getAllPosts.length !== 0) &&
              (data.getAllPosts.filter(obj=>( (employeeFilter!="") ? (obj.EmployeeType==employeeFilter):
              (obj.EmployeeType!='')))).filter(fltrList=>((searchParam!="") ? (fltrList.FirstName.toLowerCase()==searchParam.toLowerCase()
              || fltrList.LastName.toLowerCase()==searchParam.toLowerCase() 
              ||fltrList.Department.toLowerCase()==searchParam.toLowerCase()
              || fltrList.EmployeeType.toLowerCase()==searchParam.toLowerCase()
              || fltrList.Title.toLowerCase()==searchParam.toLowerCase() ):(fltrList.FirstName!=searchParam))).map((emp) => {
                return (
                  <tr key={emp.id}>
                    <td>{emp.FirstName}</td>
                    <td>{emp.LastName}</td>
                    <td>{emp.Age}</td>
                    <td>{emp.DateOfJoining}</td>
                    <td>{emp.Title}</td>
                    <td>{emp.Department}</td>
                    <td>{emp.EmployeeType}</td>
                    <td>{emp.CurrentStatus}</td>
                    <td>
                      <DeleteButton id={emp.id} status={emp.CurrentStatus} />
                    </td>
                    <td> <form method='get' action='/Update'>
                      <input type='hidden' value={emp.id} name='empID' id='empID'></input>
                      <Button type='submit' bg="success"> Update</Button>
                    </form>
                    </td>
                      <td> <form method='get' action='/View'>
                        <input type='hidden' value={emp.id} name='empID' id='empID'></input>
                        <Button type='submit' bg="warning"> View</Button>
                      </form>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </Table>
      </div></>
  )
}

export default EmployeeTable