import React from 'react'
import EmployeeSearch from './EmployeeSearch.jsx'
import EmployeeCreate from './EmployeeCreate.jsx'
import EmployeeTable from './EmployeeTable.jsx'
import Layout from './Layout.jsx'
import { BrowserRouter,Route,Routes } from 'react-router-dom';
import ViewRecord from './ViewRecord.jsx'
import UpdateRecord from './UpdateRecord.jsx'
import UpcomingRetirements from './UpcomingRetirements.jsx'



function EmployeeDirectory() {
  
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Layout />}>
        <Route index element={<EmployeeSearch />} />
        
        <Route path='/create' element={<EmployeeCreate />} />

        <Route path='/showall' element={<EmployeeTable />} />

        <Route path='/Update' element={<UpdateRecord/>} />

        <Route path='/View' element={<ViewRecord/>} />

        <Route path='/UpcomingEvents' element={<UpcomingRetirements/>} />
      </Route>
    </Routes>
   </BrowserRouter>
  )
}

export default EmployeeDirectory