import React from 'react'
import EmployeePost from '../apicalls/EmployeePost'
import { useQuery, gql, useMutation } from "@apollo/client";
import Button from 'react-bootstrap/esm/Button';

const REMOVE_EMP = EmployeePost.deletePost();
function DeleteButton(props) {
    const [deleteEmp, {loading,error}] = useMutation(REMOVE_EMP);
      function  handleDelete(id,status) {
        if(status==1 || status=='1'){
            alert("CAN'T DELETE EMPLOYEE – STATUS ACTIVE") ;
            return;     
        }
        if (loading)
      return <h1> Deleting </h1>
    
    if (error)
      return <h1> Record Cannot be Deleted {error.message}</h1>
        deleteEmp({
            variables: {
              deletePostId: id
            },
          }).then(window.location.reload()); 
      }

    return (
    <div>
        <Button key={props.id} bg="warning"  onClick={ ()=>handleDelete(props.id,props.status)}>
            Delete
        </Button>
    </div>
  )
}

export default DeleteButton