import React from 'react'
import EmployeePost from '../apicalls/EmployeePost.jsx';
import { useQuery } from '@apollo/client';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const GET_EMP = EmployeePost.viewPost();
const ID = new URLSearchParams(window.location.search).get("empID");
function ViewRecord() {
  const { data } = useQuery(GET_EMP,{variables:{getPostId:ID}});
  
  if(data){
  console.log(ID+"\n"+JSON.stringify(data.getPost));
  return (
    <Container>
      <h2> Employee Details </h2>
      <Row>
        <Col>
        <p> <strong> First Name: </strong> </p>
        </Col>
        <Col>
        <p>{data.getPost.FirstName} </p>
        </Col>
      </Row>
      <Row> 
        <Col>
        <p> <strong> Last Name: </strong> </p>
        </Col>
        <Col>
        <p> {data.getPost.LastName} </p>
        </Col>
      </Row>
      <Row>
        <Col>
        <p> <strong> Age: </strong>  </p>
        </Col>
       <Col>
       <p> {data.getPost.Age}  </p>
       </Col>
      </Row>
      <Row>
        <Col>
        <p> <strong> Date Of Joining: </strong>   </p>
        </Col>
        <Col>
        <p> {data.getPost.DateOfJoining}  </p> 
        </Col>
      </Row>
      <Row>
        <Col>
        <p> <strong> Job Title: </strong>  </p>
        </Col>
        <Col>
        <p> {data.getPost.Title} </p>
        </Col>
      </Row>
      <Row>
        <Col>
        <p> <strong> Department: </strong> </p>
        </Col>
        <Col>
        <p> {data.getPost.Department}  </p>
        </Col>
      </Row>
      <Row>
        <Col>
        <p> <strong>  Employee Type:  </strong> </p>
        </Col>
        <Col>
        <p> {data.getPost.EmployeeType} </p>
        </Col>
      </Row>
      <Row>
        <Col>
        <p> <strong> Current Status: </strong> </p>
        </Col>
        <Col>
        <p> {data.getPost.CurrentStatus}</p>
        </Col>
      </Row>
    </Container>
  )
  }
  else{
    return (
      <h1> No record Found</h1>
    )
  }
}

export default ViewRecord