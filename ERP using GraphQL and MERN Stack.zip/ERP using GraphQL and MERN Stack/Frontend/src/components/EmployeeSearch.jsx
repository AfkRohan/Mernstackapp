import React from 'react'
import Button from 'react-bootstrap/Button';

function EmployeeSearch() {
  return (
    <div>
        <form method='get' action='/showall'>
            <input type='text' name='emplsearch' id='emplysearch'  placeholder='Type search query here... '></input>
            <Button type='submit' variant="primary">Search</Button>
        </form>
    </div>
  )
}

export default EmployeeSearch