import React from 'react'
import '../styles/Error.css'

function ValidationMessage({msg}) {
  return (
    <div className='error'>
        <p> 
        {msg}
        </p>
        </div>
  )
}

export default ValidationMessage