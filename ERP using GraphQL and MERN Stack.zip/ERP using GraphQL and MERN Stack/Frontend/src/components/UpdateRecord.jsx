import React, { useEffect, useState } from 'react'

import EmployeePost from '../apicalls/EmployeePost.jsx';
import { useMutation, useQuery } from '@apollo/client';
import { useNavigate } from 'react-router-dom';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/esm/Button';

const GET_EMP = EmployeePost.viewPost();
const UPD_EMP = EmployeePost.updatePost();

const ID = new URLSearchParams(window.location.search).get("empID");

function UpdateRecord() {
  const [inputs,setInputs] = useState({})
  const { data,loading,error } = useQuery(GET_EMP,{variables:{getPostId:ID}});
  const [updateFunc,{udata,uloading,uerror}] = useMutation(UPD_EMP)
  
   const changeHandler = (event)=>{

    const name = event.target.name
    const value = event.target.value

    setInputs((values)=>({
        ...values ,[name]:value
    }))
   }

   const handleSubmit = (e) => {
    e.preventDefault()
    setInputs({inputs});
    updateFunc({variables:{
        updatePostId: ID,
        post: {
          FirstName : inputs.firstName,
          LastName : inputs.lastName,
          Age : parseInt(inputs.age),
          DateOfJoining : inputs.startDate,
          Title : inputs.title,
          Department : inputs.department, 
          EmployeeType : inputs.employeeType,
          CurrentStatus : parseInt(inputs.CurrentStatus)
          } 
      }}).then(()=>{
          setInputs({
              FirstName:udata?.getPost.FirstName,
              LastName:udata?.getPost.LastName,
              Age:parseInt(udata?.getPost.Age),
              DateOfJoining:udata?.getPost.DateOfJoining,
              Title:udata?.getPost.Title,
              Department:udata?.getPost.Department,
              EmployeeType:udata?.getPost.EmployeeType,
              CurrentStatus:parseInt(udata?.getPost.CurrentStatus)
          });
          console.log(inputs)
        alert("Employee updated successfully"+"\n "+JSON.stringify(inputs))
      }).then(()=>{
      window.location.href = `/View?empID=${ID}`
      }).catch(function (error) {
        alert(error);
      })
   }
  
   useEffect(()=>{
    setInputs({
        FirstName:data?.getPost.FirstName,
        LastName:data?.getPost.LastName,
        Age:parseInt(data?.getPost.Age),
        DateOfJoining:data?.getPost.DateOfJoining,
        Title:data?.getPost.Title,
        Department:data?.getPost.Department,
        EmployeeType:data?.getPost.EmployeeType,
        CurrentStatus:parseInt(data?.getPost.CurrentStatus)
    });
    console.log(inputs)
  },[data])

  if(inputs){
  console.log(ID+"\n"+JSON.stringify(data?.getPost));
  return (
    <div>
      <h2>Edit Employee Details here </h2>
      <form  onSubmit={handleSubmit}>
      <div>
        <label> First Name:</label>
         <input id='FirstName' name='FirstName' value={inputs.FirstName} disabled onChange={changeHandler}/> 
      </div>
      <div> 
      <label> Last Name:</label>
       <input id="LastName" name='LastName' value={inputs.LastName} disabled  onChange={changeHandler}/>
      </div>
      <div>
      <label> Age:</label> 
        <input id ='Age' type='number'  name='Age' value={inputs.Age} disabled  onChange={changeHandler} />  
      </div>
      <div>
        <label> Date Of Joining </label>
        <input id='DateOfJoining' type='date'  name='DateOfJoining' disabled  value={inputs.DateOfJoining} onChange={changeHandler} />
      </div>
      <div>
        <label> Job Title</label>
        <input  id='Title' name='Title' value={inputs.Title} onChange={changeHandler} /> 
      </div>
      <div>
        <label> Department</label>
        <input  id='department' value={inputs.Department} name='Department' onChange={changeHandler} />   
      </div>
      <div>
        <label> Employee Type</label>
        <input id='empType' name='EmployeeType' value={inputs.EmployeeType} disabled  onChange={changeHandler} />   
      </div>
      <div>
      <label> Current Status:</label> 
        <input id ='CurrentStatus' type='number'  name='CurrentStatus' value={inputs.CurrentStatus}  onChange={changeHandler} />  
      </div>
      <div>
        <Button bs='primary' type='submit'> Update </Button>
      </div>
      </form>
    </div>
  )
  }
  else{
    return (
      <h1> No record Found</h1>
    )
  }
}

export default UpdateRecord