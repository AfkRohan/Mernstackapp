import {useState } from 'react'
import React from 'react'
import EmployeePost from '../apicalls/EmployeePost'
import { useQuery, gql, useMutation } from "@apollo/client";
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';

const currentDate = new Date();

const retirementAge = 65;

const EMPS_QUERY = EmployeePost.getEmployeesFromDb();

function UpcomingRetirements() {

  function checkRetirement (doj,age){
    let dateParts = doj.split("-");
     
    let val1 =  currentDate.getDay() + currentDate.getMonth()*(30.44) + currentDate.getFullYear()*365.25 ;
   
    let val2 = Number(dateParts[0])*(365.25)  + Number(dateParts[1])*(30.44) + Number(dateParts[2]) ;
   
    let evalu = (val1 - val2) + (age-64.5)*365.25;
    console.log(evalu)
    let nearRetirement = ( Math.abs(evalu) < 180 ) ? true : false  
    console.log(nearRetirement)
    return nearRetirement;
  }
  
  const{ data, loading, error } = useQuery(EMPS_QUERY);
  const [employeeFilter,setFilter] = useState("")

  if (loading) return "Loading...";

  if (error) return <pre>{error.message}</pre>
  console.log(data);

  return (
     <><Form.Select bsPrefix='form-control' onChange={function () { 
      setFilter(event.target.value); 
      }}>
      <option value=""> All </option>
      <option value="full-time">Full Time</option>
      <option value="part-time">Part Time</option>
      <option value="contract">Contract</option>
      <option value="seasonal">Seasonal</option>
    </Form.Select   ><div>
      <h4>{employeeFilter}</h4>
        <h3> Employees </h3>
        <Table striped bordered hover size="sm">
          <caption>List of Employees</caption>
          <thead>
            <tr>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Age</th>
              <th scope="col">Date Of Joining</th>
              <th scope="col">Title</th>
              <th scope="col">Department</th>
              <th scope="col">Employee Type</th>
              <th scope="col">Current Status</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
            {(data.getAllPosts !== undefined && data.getAllPosts.length !== 0) &&
              (data.getAllPosts.filter(obj=>( (employeeFilter!="")? (obj.EmployeeType==employeeFilter && ((checkRetirement(obj.DateOfJoining,parseInt(obj.Age)) ))):
              (obj.EmployeeType!='' && (checkRetirement(obj.DateOfJoining,parseInt(obj.Age)))))).map((emp) => {
                return (
                  <tr key={emp.id}>
                    <td>{emp.FirstName}</td>
                    <td>{emp.LastName}</td>
                    <td>{emp.Age}</td>
                    <td>{emp.DateOfJoining}</td>
                    <td>{emp.Title}</td>
                    <td>{emp.Department}</td>
                    <td>{emp.EmployeeType}</td>
                    <td>{emp.CurrentStatus}</td>
                  </tr>
                );
              }))}
          </tbody>
        </Table>
      </div></>
  )
}

export default UpcomingRetirements