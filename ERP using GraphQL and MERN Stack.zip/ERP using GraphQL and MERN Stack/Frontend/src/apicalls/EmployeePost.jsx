import { gql } from '@apollo/client'

class EmployeePost{

    static insert(){

        return gql`mutation CreatePost($post: PostInput){
            createPost(post: $post) {
              id
              FirstName
              LastName
              Age
              DateOfJoining
              Title
              Department
              EmployeeType
              CurrentStatus
            }
          }`
    }

    static getEmployeesFromDb(){

        return  gql`
        {
          getAllPosts {
            Age
            DateOfJoining
            Department
            FirstName
            EmployeeType
            LastName
            Title
            CurrentStatus
            id
          }
        }
        `;
    }

    static deletePost(){
      return gql`mutation DeletePost($deletePostId: ID) {
                deletePost(id: $deletePostId)
      }`;
    }
    
    static updatePost(){
      return gql`mutation updatePost($updatePostId: ID, $post: PostInput) {
        updatePost(id: $updatePostId, post: $post) {
          id
          FirstName
          LastName
          Age
          DateOfJoining
          Title
          Department
          EmployeeType
          CurrentStatus
        }
      }`
    }

    static viewPost(){
      return gql`query GetPost($getPostId: ID) {
        getPost(id: $getPostId) {
          id
          FirstName
          LastName
          Age
          DateOfJoining
          Title
          Department
          EmployeeType
          CurrentStatus
        }
      }`;
    }

}

export default EmployeePost