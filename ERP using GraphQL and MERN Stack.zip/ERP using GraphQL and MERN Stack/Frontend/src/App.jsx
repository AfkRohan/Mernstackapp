
import './App.css';
import EmployeeDirectory from './components/EmployeeDirectory.jsx';
import EmployeeSearch from './components/EmployeeSearch.jsx';
import EmployeeCreate from './components/EmployeeCreate.jsx';
import EmployeeTable from './components/EmployeeTable.jsx';
import './styles/EmployeeCreate.css'


function App() {
  return (
    <div className='App'>
      <EmployeeDirectory/>
    </div>
  );
}

export default App;
