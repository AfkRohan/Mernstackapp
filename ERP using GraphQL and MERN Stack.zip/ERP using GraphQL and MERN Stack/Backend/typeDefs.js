const {gql} = require('apollo-server-express');

const typeDefs = gql`

     type Post{
        id : ID
        FirstName : String
        LastName : String
        Age : Int
        DateOfJoining : String 
        Title : String 
        Department : String 
        EmployeeType : String
        CurrentStatus : Int
     }

    type Query {
       
        getAllPosts : [Post]
        getPost(id:ID) : Post

    }

    input PostInput{
        FirstName : String
        LastName : String
        Age : Int 
        DateOfJoining : String 
        Title : String 
        Department : String 
        EmployeeType : String
        CurrentStatus : Int
     }

    type Mutation {
        createPost(post:PostInput):Post
        deletePost(id:ID):String
        updatePost(id:ID , post:PostInput):Post
    }

`;

module.exports = typeDefs ;
