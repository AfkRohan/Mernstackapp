

// // ---- Using Express

// const express = require('express')

// const cors = require('cors')

// const Post = require('./models/Post.model')

// const bodyParser = require('body-parser')

// const app = express()

// app.listen(4000,()=>{
//     console.log("Server is listening at port 4000 !!!!!!!!!!")
// })

// app.use(cors({
//     origin:"*"
// }))

// app.use(bodyParser.json())

// app.use(bodyParser.urlencoded({extended:true}))

// app.post('/create',async (req,res)=>{
//     const data = req.body
//     console.log(data)

//     try{
//         const emp = new Post({
//     FirstName : data.firstName,
//     LastName : data.lastName,
//     Age: data.age,
//     DateOfJoining: data.startDate,
//     Title:data.title,
//     Department: data.department,
//     EmployeeType: data.employeeType
//     })
//     const empInserted_to_mongodb = await emp.save();
//       console.log(empInserted_to_mongodb);
//       res.send(empInserted_to_mongodb);
//     }
//     catch(err){
//       res.send(`<h1style='color:red;'>${err}</h1>`)
//     }
// })

// app.get('/getEmp',async(req,res)=>{
//   try{
//     const emp_from_db = await Post.find({})
//     console.log(emp_from_db)
//     res.send(emp_from_db)
//   }
//   catch(err){
//     res.send(err)
//   }

// })

// ----------- GraphQL Version --------


const express = require('express');
const { ApolloServer , gql } = require('apollo-server-express');
// Now importing typeDefs and resolvers

const typeDefs = require('./typeDefs');
const resolvers = require('./resolvers'); 

const mongoose = require('mongoose');

// // Create Type defs and Resolvers initially here and then they will be moved
// // to seperate files

// // start the server using an async function

async function startServer(){

    const app = express();

    const apolloServer = new ApolloServer({

        typeDefs ,
        resolvers,
    });
await apolloServer.start();
apolloServer.applyMiddleware({app:app})


app.use((req,res)=>{
res.send("Hello from Appolo Server!!!!");
});
await mongoose.connect("mongodb+srv://topa:topachuptha@cluster0.ldhu0gj.mongodb.net/employees?retryWrites=true&w=majority",{
    useNewUrlParser: true ,
    useUnifiedTopology: true,
});
console.log("***Mongoose Connected***");
app.listen(4000,()=>{console.log("App is running at port 4000!")});
}
startServer();