const mongoose = require('mongoose');

mongoose.connect("mongodb+srv://topa:topachuptha@cluster0.ldhu0gj.mongodb.net/employees?retryWrites=true&w=majority",{
    useNewUrlParser: true ,
    useUnifiedTopology: true,
})
.then(console.log("***Mongoose Connected***"))
.catch((error)=>console.log(error))


const postSchema = new mongoose.Schema({

    FirstName :{
        type:String,
        required : true
    },
    LastName :{
        type:String,
        required : true
    },
    Age:{
        type:Number,
        required : true
    },
    DateOfJoining:{
        type:String,
        required : true
    },
    Title:{
        type:String,
        required : true
    },
    Department:{
        type:String,
        required : true
    },
    EmployeeType:{
        type:String,
        required : true
    },
    CurrentStatus:{
        type:Number,
        required:true
    }
});

const Post = mongoose.model('Post',postSchema);
module.exports = Post ;
