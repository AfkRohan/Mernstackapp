const Post = require("./models/Post.model");

const resolvers = {

    Query :{

         getAllPosts:async ()=>{
          return await Post.find();
        },
        
        getPost: async(_parent,{id},_context,_info)=>{
          return await Post.findById(id);
        },
      },

    Mutation :{

        createPost:async(parent,args,context,info)=>{

            const{FirstName,LastName,Age,DateOfJoining,Title,Department,EmployeeType,CurrentStatus} = args.post ;

            const post = new Post({FirstName,LastName,Age,DateOfJoining,Title,Department,EmployeeType,CurrentStatus});

            await post.save() ;

            return post ;

        },
        deletePost:async(parent,args,context,info)=>{
           
          const {id}= args;
          await Post.findByIdAndDelete(id);

          return("Post Deletd Successfully!!!");

        },
        updatePost:async(parent,args,context,info)=>{
           const {id}= args;
           const{FirstName,LastName,Age,DateOfJoining,Title,Department,EmployeeType,CurrentStatus} = args.post ;

           const post = await Post.findByIdAndUpdate(
             id ,
             {FirstName,LastName,Age,DateOfJoining,Title,Department,EmployeeType,CurrentStatus},
             {new : true}
           );
           return post ;

        },

    },

    
}

 ;

module.exports = resolvers ;
